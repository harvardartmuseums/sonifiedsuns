
1.1.0 / 2014-07-05
==================

 * add CONNECT
 
1.0.1 / 2014-06-02
==================

 * fix index.js to work with harmony transform

1.0.0 / 2014-05-08
==================

 * add PURGE. Closes #9

0.1.0 / 2013-10-28
==================

 * add http.METHODS support
